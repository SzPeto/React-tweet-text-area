import { ConflictException, Injectable, NotFoundException } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { Model } from 'mongoose'
import * as bcrypt from 'bcrypt'
import { User, UserDocument } from './schemas/users.schema'
import { CreateUserDto } from './dto/create-user.dto'


@Injectable()
export class UsersService {

  constructor(@InjectModel(User.name) private userModel: Model<UserDocument>) {}

  async createUser(createUserDto: CreateUserDto) {
    const userExist = await this.userModel.findOne({ userName: createUserDto.userName })
    if (userExist) {
      throw new ConflictException(`User with name ${ createUserDto.userName } already exists!`)
    }
    const hashedPw = await bcrypt.hash(createUserDto.password, 10)
    const user = new this.userModel({ 
      userName: createUserDto.userName, 
      email: createUserDto.email, 
      password: hashedPw 
    })
    return user.save()
  }

  async findUserByName(userName: string) {
    const user = await this.userModel.findOne({ userName: userName })
    if (!user) {
      throw new NotFoundException(`User with name ${ userName } doesn't exist`)
    }
    return user
  }

  async findUserById(id: string) {
    const user = await this.userModel.findOne({ _id: id })
    if (!user) {
      throw new NotFoundException(`User with id ${ id } doesn't exist`)
    }
    return user
  }

  async getAllUsers() {
    return await this.userModel.find()
  }

  async updateRefreshTokenHash(userId: string, hash: string) {
    await this.userModel.updateOne({ _id: userId }, { $set: { refreshTokenHash: hash } })
  }

  async removeRefreshTokenHash(userId: string) {
    await this.userModel.updateOne({ _id: userId }, { $set: { refreshTokenHash: null } })
  }

}