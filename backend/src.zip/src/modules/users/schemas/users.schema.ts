import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { HydratedDocument } from 'mongoose'

export type UserDocument = HydratedDocument<User>

@Schema({ timestamps: true })
export class User {

  @Prop({ required: true, unique: true, trim: true })
  userName: string

  @Prop({ required: true, unique:true, trim: true })
  email: string

  @Prop({ required: true })
  password: string

  @Prop({ default: '/uploads/profile-pictures/Default - user.jpg' })
  picturePath: string

  @Prop({ default: false })
  isAdmin: boolean

  @Prop({ default: null, type: String })
  refreshTokenHash: string | null

}

export const UserSchema = SchemaFactory.createForClass(User)