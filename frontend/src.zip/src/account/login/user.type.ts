import type { User as SwaggerUser } from "@/_api"  

export type UserType = SwaggerUser