export type User = {
  _id: string,
  userName: string,
  email: string,
  picturePath: string,
  isAdmin: boolean
}