export type TweetType = {
  _id: string
  content: string
  dateSubmitted: string
}