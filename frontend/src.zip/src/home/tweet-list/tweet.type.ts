import type { Tweet as SwaggerTweet } from "@/_api"  

export type TweetType = SwaggerTweet